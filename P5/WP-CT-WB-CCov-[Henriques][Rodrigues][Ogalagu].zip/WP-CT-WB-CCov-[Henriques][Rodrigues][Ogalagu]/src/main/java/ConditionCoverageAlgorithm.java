public interface ConditionCoverageAlgorithm {
    Truthtable create(Truthtable truthtable);
}
